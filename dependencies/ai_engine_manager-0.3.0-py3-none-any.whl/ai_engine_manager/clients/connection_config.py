import os
from typing import Any, NamedTuple

import h2o_authn
import h2o_discovery
from ai_engine_manager.clients.h2o_cli_config import CLIConfig

# Default path to h2o cli config file.
DEFAULT_CONFIG_PATH = "~/.h2oai/h2o-cli-config.toml"
# Name of the platform client in the discovery response.
PLATFORM_CLIENT_NAME = "platform"
# Name of the AIEM service in the discovery response.
AIEM_SERVICE_NAME = "aiem"


class ConnectionConfig(NamedTuple):
    """Object holding connection configuration for the AIEM server."""

    aiem_url: str
    token_provider: Any


def get_connection(
    aiem_url: str,
    platform_token: str,
    platform_oidc_url: str,
    platform_oidc_client_id: str,
) -> ConnectionConfig:
    """Creates ConnectionConfig object. Initializes and tests token provider."""

    # init token provider
    tp = h2o_authn.TokenProvider(
        issuer_url=platform_oidc_url,
        client_id=platform_oidc_client_id,
        refresh_token=platform_token,
    )
    # test token refresh
    tp()

    return ConnectionConfig(aiem_url=aiem_url, token_provider=tp)


def discover_connection(
    platform_url: str = "", platform_token: str = "", config_path: str = ""
) -> ConnectionConfig:
    """Creates ConnectionConfig object by discovering configuration from the discovery server.
    Fills missing optional arguments from H2O CLI configuration.
    """
    resolved_url = ""
    resolved_token = ""

    # Read H2O CLI config file if a required argument is not provided
    if not platform_url or not platform_token:

        # if default, convert to platform appropriate format
        if config_path == DEFAULT_CONFIG_PATH:
            config_path = os.path.abspath(os.path.expanduser(DEFAULT_CONFIG_PATH))

        cli_cfg = CLIConfig(config_path)
        if cli_cfg.url:
            resolved_url = cli_cfg.url
        if cli_cfg.token:
            resolved_token = cli_cfg.token

    # higher priority given to specified arguments
    if platform_url:
        resolved_url = platform_url
    if platform_token:
        resolved_token = platform_token

    if not resolved_url:
        raise ValueError("Please set the 'url' argument or configure the H2O CLI")
    if not resolved_token:
        raise ValueError(
            "Please set the 'platform_token' argument or configure the H2O CLI"
        )

    d = h2o_discovery.discover(environment=resolved_url)

    # validate discovered values
    client_id = d.clients.get(PLATFORM_CLIENT_NAME).oauth2_client_id
    aiem_url = d.services.get(AIEM_SERVICE_NAME).uri
    if not client_id:
        raise ConnectionError(
            "Unable to discover platform oauth2_client_id connection value."
        )

    if not aiem_url:
        raise ConnectionError("Unable to discover AIEM server URL connection value.")

    # init token provider
    tp = h2o_authn.TokenProvider(
        issuer_url=d.environment.issuer_url,
        client_id=client_id,
        refresh_token=resolved_token,
    )
    # test token refresh
    tp()

    return ConnectionConfig(
        aiem_url=aiem_url,
        token_provider=tp,
    )
