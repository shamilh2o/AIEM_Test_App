from ai_engine_manager.clients.dai_engine.dai_engine_client import DAIEngineClient
from ai_engine_manager.clients.h2o_engine.client import H2OEngineClient
from ai_engine_manager.clients.connection_config import ConnectionConfig, DEFAULT_CONFIG_PATH, get_connection, discover_connection


class Clients:
    def __init__(self, dai_engine_client: DAIEngineClient, h2o_engine_client: H2OEngineClient) -> None:
        self.dai_engine_client = dai_engine_client
        self.h2o_engine_client = h2o_engine_client


def login(
    url: str = "",
    token_provider = None,
    platform_token: str = "",
    default_workspace_id: str = "default",
    config_path: str = DEFAULT_CONFIG_PATH,
) -> Clients:
    """Initializes AI Engine Manager clients for H2O AI Cloud.

    Args:
        url (str, optional): H2O AI Cloud URL (https://cloud.h2o.ai/). If none is provided, the H2O CLI configuration will be read.
        token_provider (optional) = Function providing access token. Mutually exclusive with platform_token argument.
        platform_token (str, optional): H2O Platform Token. If none is provided, the H2O CLI configuration will be read.
        default_workspace_id (str, optional): The default workspace ID which will client use to manipulate with resources. Defaults to `default`.
        config_path: (str, optional): Path to the H2O AI Cloud configuration file. Defaults to ~/.h2oai/h2o-cli-config.toml)

    Raises:
        FileNotFoundError: When a required argument is not provided and no configuration file can be found.
        TomlDecodeError: When a required argument is not provided and the configuration file cannot be processed.
        ConnectionError: When a communication with server failed.
    """
    if token_provider is not None:
        cfg = ConnectionConfig(aiem_url=url, token_provider=token_provider)

    else:
        cfg = discover_connection(platform_url=url, platform_token=platform_token, config_path=config_path)

    return __init_clients(cfg, default_workspace_id)


def login_custom(
    aiem_url: str,
    platform_token: str,
    platform_oidc_url: str,
    platform_oidc_client_id: str,
    default_workspace_id: str = "default",
) -> Clients:
    """Initializes AI Engine Manager clients.
    This function does not utilize any discovery mechanism. All login arguments must be provided explicitly.

    Args:
        aiem_url (str): URL of the AIEM server.
        platform_token (str): H2O Platform Token.
        platform_oidc_url (str): Base URL of the platform_token OIDC issuer.
        platform_oidc_client_id (str): OIDC Client ID associated with the platform_token.
        default_workspace_id (str, optional): The default workspace ID which will client use to manipulate with resources. Defaults to `default`.
    """

    cfg = get_connection(aiem_url=aiem_url, platform_token=platform_token, platform_oidc_url=platform_oidc_url,
                         platform_oidc_client_id=platform_oidc_client_id)

    return __init_clients(cfg, default_workspace_id)


def __init_clients(cfg: ConnectionConfig, default_workspace_id: str):
    dai_engine_client = DAIEngineClient(connection_config=cfg, default_workspace_id=default_workspace_id)
    h2o_engine_client = H2OEngineClient(connection_config=cfg, default_workspace_id=default_workspace_id)
    return Clients(dai_engine_client=dai_engine_client, h2o_engine_client=h2o_engine_client)