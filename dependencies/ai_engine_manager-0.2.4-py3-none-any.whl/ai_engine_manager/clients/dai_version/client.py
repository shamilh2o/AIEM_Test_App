from typing import List

import h2o_authn
from ai_engine_manager.clients.dai_version.dai_version import DAIVersion
from ai_engine_manager.clients.dai_version.page import DAIVersionsPage
from ai_engine_manager.clients.dai_version.token_api_client import (
    TokenApiDAIVersionClient,
)
from ai_engine_manager.clients.exception import ApiException
from ai_engine_manager.clients.server_config import Urllib3ServerConfigClient
from ai_engine_manager.gen.dai_version_service import ApiException as GenApiException
from ai_engine_manager.gen.dai_version_service.api.dai_version_service_api import (
    DAIVersionServiceApi,
)
from ai_engine_manager.gen.dai_version_service.configuration import (
    Configuration as DAIVersionConfiguration,
)


class DAIVersionClient:
    """DAIVersionClient manages Driverless AI versions."""

    def __init__(self, url: str, platform_token: str):
        """Initializes DAIVersionClient.

        Args:
            url (str): URL of AI Engine Manager Gateway.
            platform_token (str): H2O.ai platform token.
        """

        cfg = Urllib3ServerConfigClient().get_config(server_base_url=url)

        tp = h2o_authn.TokenProvider(
            token_endpoint_url=cfg.token_endpoint,
            client_id=cfg.platform_client_id,
            refresh_token=platform_token,
        )

        configuration_dai_version = DAIVersionConfiguration(host=url)
        with TokenApiDAIVersionClient(
            configuration_dai_version, tp
        ) as api_dai_version_client:
            self.api_version_instance = DAIVersionServiceApi(api_dai_version_client)

    def list_versions(
        self,
        page_size: int = 0,
        page_token: str = "",
        order_by: str = "",
        filter: str = "",
    ) -> DAIVersionsPage:
        exc = None
        list_response = None

        try:
            list_response = (
                self.api_version_instance.d_ai_version_service_list_dai_versions(
                    page_size=page_size,
                    page_token=page_token,
                    order_by=order_by,
                    filter=filter,
                )
            )
        except GenApiException as e:
            exc = ApiException(e)

        if exc:
            raise exc

        return DAIVersionsPage(list_response)

    def list_all_versions(
        self, order_by: str = "", filter: str = ""
    ) -> List[DAIVersion]:
        all_versions: List[DAIVersion] = []
        next_page_token = ""
        while True:
            versions_list = self.list_versions(
                page_size=0,
                page_token=next_page_token,
                order_by=order_by,
                filter=filter,
            )
            all_versions = all_versions + versions_list.dai_versions
            next_page_token = versions_list.next_page_token
            if next_page_token == "":
                break

        return all_versions
