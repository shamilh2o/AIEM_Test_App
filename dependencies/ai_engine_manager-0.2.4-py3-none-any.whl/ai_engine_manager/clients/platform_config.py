import os

from ai_engine_manager.clients.h2o_cli_config import CLIConfig
from ai_engine_manager.clients.server_config import Urllib3ServerConfigClient

# Default path to h2o cli config file.
DEFAULT_CONFIG_PATH = "~/.h2oai/h2o-cli-config.toml"


class PlatformConfig:
    """Help class for resolving platform URL, platform token and AIEM well-known config either from H2O CLI config
    or passed params"""

    def __init__(self, url: str, platform_token: str, config_path: str):
        cfg_url = ""
        cfg_token = ""

        # Read config file if a required argument is not provided
        if not url or not platform_token:

            # if default, convert to platform appropriate format
            if config_path == DEFAULT_CONFIG_PATH:
                config_path = os.path.abspath(os.path.expanduser(DEFAULT_CONFIG_PATH))

            cli_cfg = CLIConfig(config_path)
            if cli_cfg.url:
                cfg_url = cli_cfg.url
            if cli_cfg.token:
                cfg_token = cli_cfg.token

        # higher priority given to specified arguments
        if url:
            cfg_url = url
        if platform_token:
            cfg_token = platform_token

        if not cfg_url:
            raise ValueError("Please set the 'url' argument or configure the H2O CLI")
        if not cfg_token:
            raise ValueError(
                "Please set the 'platform_token' argument or configure the H2O CLI"
            )

        # remove trailing slash for generated client
        cfg_url = cfg_url.rstrip("/")
        # attempt to connect with URL as is, if any exception is raised, try with `aiem` prefixed URL
        try:
            cfg = Urllib3ServerConfigClient().get_config(server_base_url=cfg_url)
        except Exception:
            cfg_url = CLIConfig.build_aiem_url(cfg_url)
            cfg = Urllib3ServerConfigClient().get_config(server_base_url=cfg_url)

        self.cfg_url = cfg_url
        self.cfg_token = cfg_token
        self.cfg = cfg
