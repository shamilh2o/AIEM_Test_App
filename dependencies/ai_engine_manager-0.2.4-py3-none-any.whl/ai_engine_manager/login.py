import h2o_authn

from ai_engine_manager.clients.dai_engine.dai_engine_client import DAIEngineClient
from ai_engine_manager.clients.h2o_engine.client import H2OEngineClient
from ai_engine_manager.clients.platform_config import DEFAULT_CONFIG_PATH, PlatformConfig


class Clients:
    def __init__(self, dai_engine_client: DAIEngineClient, h2o_engine_client: H2OEngineClient) -> None:
        self.dai_engine_client = dai_engine_client
        self.h2o_engine_client = h2o_engine_client


def login(
    url: str = "",
    platform_token: str = "",
    default_workspace_id: str = "default",
    config_path: str = DEFAULT_CONFIG_PATH,
) -> Clients:
    """Initializes AI Engine Manager clients.

    Args:
        url (str, optional): H2O AI Cloud URL (or AIEM server base URL). If none is provided, the H2O CLI configuration will be read.
        platform_token (str, optional): H2O Platform Token. If none is provided, the H2O CLI configuration will be read.
        default_workspace_id (str, optional): The default workspace ID which will client use to manipulate with resources. Defaults to `default`.
        config_path: (str, optional): Path to the H2O AI Cloud configuration file. Defaults to ~/.h2oai/h2o-cli-config.toml)

    Raises:
        FileNotFoundError: When a required argument is not provided and no configuration file can be found.
        TomlDecodeError: When a required argument is not provided and the configuration file cannot be processed.
    """
    p_cfg = PlatformConfig(
        url=url, platform_token=platform_token, config_path=config_path
    )

    tp = h2o_authn.TokenProvider(
        token_endpoint_url=p_cfg.cfg.token_endpoint,
        client_id=p_cfg.cfg.platform_client_id,
        refresh_token=p_cfg.cfg_token,
    )
    # test token refresh
    tp()

    dai_engine_client = DAIEngineClient(platform_config=p_cfg, token_provider=tp, default_workspace_id=default_workspace_id)
    h2o_engine_client = H2OEngineClient(platform_config=p_cfg, token_provider=tp, default_workspace_id=default_workspace_id)
    return Clients(dai_engine_client=dai_engine_client, h2o_engine_client=h2o_engine_client)
