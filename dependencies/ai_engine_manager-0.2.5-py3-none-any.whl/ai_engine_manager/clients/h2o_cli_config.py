from urllib.parse import urlparse

import toml


class CLIConfig:
    # TODO not used now due to CLI config fixed for a specific OIDC client.
    def __init__(self, path) -> None:
        """Read H2O CLI config file from users home directory.

        Args:
            path: (str, optional): Path to h2o CLI config file."

        Raises
            FileNotFoundError: When config file is not found.
            TomlDecodeError: When there is an error processing the config file.
        """
        h2o_cfg = toml.load(path)

        # Read token and URL from the H2O CLI config.
        if "PlatformToken" in h2o_cfg:
            self.token = h2o_cfg["PlatformToken"]
        else:
            self.token = ""

        if "Endpoint" in h2o_cfg:
            self.url = h2o_cfg["Endpoint"]
        else:
            self.url = ""

    @staticmethod
    def build_aiem_url(cloud_url: str) -> str:
        """
        Prepends H2O.ai cloud URL in format `https://cloud-dev.h2o.ai/` with the `aiem` prefix.
        :param cloud_url: URL of a H2O.ai cloud deployment.
        :return: AIEM-specific URL of given cloud deployment.
        """
        parsed_url = urlparse(cloud_url)
        scheme = f"{parsed_url.scheme}://"
        cloud_url = parsed_url.geturl().replace(scheme, "", 1)
        return f"{scheme}aiem.{cloud_url}"
