import json
from typing import Any, Mapping, NamedTuple
from urllib.parse import urljoin

import urllib3


class WellKnownConfig(NamedTuple):
    """Represents AIEM server well-known condifuration object."""

    token_endpoint: str
    platform_client_id: str


class Urllib3ServerConfigClient:
    """Implements client for reading server configuration."""

    def __init__(self) -> None:
        self._http = urllib3.PoolManager()

    def get_config(self, server_base_url: str) -> WellKnownConfig:
        """Reads well known config from the AIEM server on a specified url.

        Args:
            server_base_url (str): AIEM base server URL.

        Raises:
            Exception: when request was not successfull or incomplete data was returned.

        Returns:
            WellKnownConfig: WellKnownConfig object.
        """
        resp = self._http.request(
            method="GET",
            url=urljoin(server_base_url, "/.well-known/aiem-configuration"),
        )

        if not (200 <= resp.status <= 299):
            raise Exception(resp.status, resp.data)

        return config_from_response(json.loads(resp.data))


def config_from_response(resp: Mapping[str, Any]) -> WellKnownConfig:
    """Converts JSON response from well known server config endpoint to the internal representation
    tuple.

    Args:
        resp (Mapping[str, Any]): response from the well known configuration server endpoint.

    Raises:
        Exception: raised when empty or incomplete response is obtained.

    Returns:
        WellKnownConfig: WellKnownConfig object.
    """

    token_endpoint: str = resp["token_endpoint"]
    platform_client_id: str = resp["platform_client_id"]

    if not token_endpoint or not platform_client_id:
        raise Exception("empty or incomplete server configuration received")

    return WellKnownConfig(
        token_endpoint=token_endpoint, platform_client_id=platform_client_id
    )
